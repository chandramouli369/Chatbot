import React from "react";
import "./App.css"; 
import Bank from "./components/bank/Bank";

function App() {
  return <Bank />;
}

export default App;
