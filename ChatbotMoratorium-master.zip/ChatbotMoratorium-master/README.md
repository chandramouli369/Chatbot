Go to the project directory and run:

### `npm install`

In the project directory, run:

### `npm start`

Application will open on http://localhost:3000

The page will reload if you make edits.<br>
You will also see any lint errors in the console.
